# IRONLOG

Small Express-based workout tracker with a static frontend and JSON file storage.

## Local Run

```bash
npm install
npm start
```

The app listens on `process.env.PORT` when provided, otherwise `3000`.

## Data Storage

By default, the app uses `workout-data.json` in the project root if that file exists.

For hosted deployments, you can set `DATA_FILE` to a writable path outside the deployment bundle:

```env
DATA_FILE=/home/YOUR_HOSTINGER_USER/domains/ironlog.mxytzplk.org/ironlog-data/workout-data.json
```

The application will create the parent directory and file automatically if needed.

The example path above is an inference based on Hostinger's documented directory layout for domain folders. Use the actual username/path shown in hPanel.

## Hostinger Deployment

As of April 21, 2026, Hostinger supports managed Node.js web apps on:

- Business Web Hosting
- Cloud Startup
- Cloud Professional
- Cloud Enterprise
- Cloud Enterprise Plus

For `ironlog.mxytzplk.org`, use the subdomain as a separate website:

1. In hPanel, go to `Websites` -> `Add website`.
2. Choose `Node.js Apps`.
3. Enter `ironlog.mxytzplk.org`.
4. Deploy either from GitHub or by uploading a ZIP of this project.
5. Use these settings if Hostinger does not auto-detect them:
   - Framework: `Express.js` or `Other`
   - Node.js version: `20.x` or `22.x`
   - Build command: `npm install`
   - Start command: `npm start`
   - Entry file: `server.js`
6. Add the `DATA_FILE` environment variable before deploy if you want workout history stored outside the deployment directory.
7. Deploy and then open `https://ironlog.mxytzplk.org`.

If the main domain uses Hostinger nameservers, DNS for the subdomain is handled automatically. If DNS is managed elsewhere, create an `A` record for `ironlog` pointing to your Hostinger hosting IP.
