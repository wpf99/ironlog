const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const LEGACY_DATA_FILE = path.join(__dirname, 'workout-data.json');
const DEFAULT_DATA_FILE = fs.existsSync(LEGACY_DATA_FILE)
  ? LEGACY_DATA_FILE
  : path.join(__dirname, 'data', 'workout-data.json');
const DATA_FILE = process.env.DATA_FILE
  ? path.resolve(process.env.DATA_FILE)
  : DEFAULT_DATA_FILE;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ─── Data Layer ────────────────────────────────────────────

function ensureDataFile() {
  const dir = path.dirname(DATA_FILE);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(DATA_FILE, JSON.stringify({ exercises: {} }, null, 2));
  }
}

function loadData() {
  try {
    ensureDataFile();
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch (e) {
    console.error('Load error:', e.message);
  }
  return { exercises: {} };
}

function saveData(data) {
  ensureDataFile();
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

// ─── Helpers ───────────────────────────────────────────────

// Epley formula: 1RM = weight × (1 + reps/30)
function calc1RM(weight, reps) {
  if (!weight || !reps || reps <= 0 || weight <= 0) return 0;
  if (reps === 1) return weight;
  return Math.round(weight * (1 + reps / 30));
}

// Core suggestion engine — progressive overload in 5–8 rep range
function generateSuggestion(sessions, increment) {
  increment = increment || 5;

  if (!sessions || sessions.length === 0) {
    return {
      action: 'NEW', actionLabel: 'START', color: '#777',
      reason: 'No history yet. Pick a weight you can do for 5–8 reps with good form.',
      weight: 0, reps: 0, sets: 3
    };
  }

  const last = sessions[sessions.length - 1];
  const validSets = (last.sets || []).filter(s => s.weight > 0 && s.reps > 0);

  if (validSets.length === 0) {
    return {
      action: 'NEW', actionLabel: 'START', color: '#777',
      reason: 'No valid sets recorded last time.', weight: 0, reps: 0, sets: 3
    };
  }

  // Analyze top-weight sets
  const topWeight = Math.max(...validSets.map(s => s.weight));
  const topSets = validSets.filter(s => s.weight === topWeight);
  const minReps = Math.min(...topSets.map(s => s.reps));
  const maxReps = Math.max(...topSets.map(s => s.reps));
  const numSets = validSets.length;

  const prev1RM = sessions.length > 1 ? (sessions[sessions.length - 2].estimated1RM || 0) : 0;
  let sug = {};

  if (minReps >= 8) {
    // Hit 8+ on all top sets → increase weight, drop back to 5
    const nw = topWeight + increment;
    sug = {
      action: 'INCREASE_WEIGHT', actionLabel: 'UP WEIGHT', color: '#22C55E',
      weight: nw, reps: 5, sets: numSets,
      targetVolume: nw * 5 * numSets,
      reason: 'All top sets at ' + topWeight + ' hit 8+ reps. Bump to ' + nw + ' lbs, aim for 5 reps.'
    };
  } else if (minReps >= 7) {
    // One rep away from 8 → push to 8
    sug = {
      action: 'PUSH_REPS', actionLabel: 'PUSH TO 8', color: '#F59E0B',
      weight: topWeight, reps: 8, sets: numSets,
      targetVolume: topWeight * 8 * numSets,
      reason: 'Close at ' + topWeight + ' lbs. Push all sets to 8 reps, then increase weight.'
    };
  } else if (maxReps >= 6 && minReps >= 5) {
    // In 5–7 range → add 1 rep
    const tr = Math.min(maxReps + 1, 8);
    sug = {
      action: 'ADD_REP', actionLabel: '+1 REP', color: '#F59E0B',
      weight: topWeight, reps: tr, sets: numSets,
      targetVolume: topWeight * tr * numSets,
      reason: 'Stay at ' + topWeight + ' lbs. Aim for ' + tr + ' reps across your sets.'
    };
  } else if (minReps >= 5) {
    // Just hit 5 → stabilize
    sug = {
      action: 'BUILD_REPS', actionLabel: 'BUILD', color: '#F59E0B',
      weight: topWeight, reps: 6, sets: numSets,
      targetVolume: topWeight * 6 * numSets,
      reason: 'Stay at ' + topWeight + ' lbs. Focus on 6 clean reps across all sets.'
    };
  } else {
    // Below 5 → deload 10%
    const deloadW = Math.max(increment, Math.round((topWeight * 0.9) / increment) * increment);
    sug = {
      action: 'DELOAD', actionLabel: 'DELOAD', color: '#F97316',
      weight: deloadW, reps: 5, sets: numSets,
      targetVolume: deloadW * 5 * numSets,
      reason: 'Reps fell below 5 at ' + topWeight + ' lbs. Deload to ' + deloadW + ' lbs and rebuild.'
    };
  }

  sug.lastWeight = topWeight;
  sug.lastMaxReps = maxReps;
  sug.lastMinReps = minReps;
  sug.lastVolume = last.totalVolume;
  sug.lastDate = last.date;
  sug.estimated1RM = last.estimated1RM || 0;
  sug.prev1RM = prev1RM;

  return sug;
}

// ─── API Routes ────────────────────────────────────────────

app.get('/api/health', (req, res) => {
  res.json({ ok: true });
});

// List all exercises with summaries and suggestions
app.get('/api/exercises', (req, res) => {
  const data = loadData();
  const result = {};
  for (const [name, ex] of Object.entries(data.exercises)) {
    const sessions = ex.sessions || [];
    const last = sessions.length > 0 ? sessions[sessions.length - 1] : null;
    const best1RM = sessions.reduce((b, s) => Math.max(b, s.estimated1RM || 0), 0);
    const inc = ex.weightIncrement || 5;
    result[name] = {
      totalSessions: sessions.length,
      best1RM,
      weightIncrement: inc,
      lastSession: last ? {
        date: last.date,
        estimated1RM: last.estimated1RM,
        totalVolume: last.totalVolume,
        bestSet: last.bestSet,
        sets: last.sets
      } : null,
      suggestion: generateSuggestion(sessions, inc)
    };
  }
  res.json(result);
});

// Get single exercise with full session history
app.get('/api/exercises/:name', (req, res) => {
  const data = loadData();
  const name = decodeURIComponent(req.params.name);
  const ex = data.exercises[name];
  if (!ex) return res.status(404).json({ error: 'Exercise not found' });
  const sessions = ex.sessions || [];
  const best1RM = sessions.reduce((b, s) => Math.max(b, s.estimated1RM || 0), 0);
  const inc = ex.weightIncrement || 5;
  res.json({
    name, sessions, best1RM,
    totalSessions: sessions.length,
    weightIncrement: inc,
    suggestion: generateSuggestion(sessions, inc)
  });
});

// Create exercise (optional — also auto-created on session log)
app.post('/api/exercises', (req, res) => {
  const data = loadData();
  const { name, weightIncrement } = req.body;
  if (!name || !name.trim()) return res.status(400).json({ error: 'Name required' });
  const key = name.trim();
  if (!data.exercises[key]) {
    data.exercises[key] = { sessions: [], weightIncrement: weightIncrement || 5 };
    saveData(data);
  }
  res.json({ success: true });
});

// Update exercise settings
app.put('/api/exercises/:name', (req, res) => {
  const data = loadData();
  const name = decodeURIComponent(req.params.name);
  if (!data.exercises[name]) return res.status(404).json({ error: 'Not found' });
  if (req.body.weightIncrement) data.exercises[name].weightIncrement = req.body.weightIncrement;
  saveData(data);
  res.json({ success: true });
});

// Delete exercise
app.delete('/api/exercises/:name', (req, res) => {
  const data = loadData();
  const name = decodeURIComponent(req.params.name);
  delete data.exercises[name];
  saveData(data);
  res.json({ success: true });
});

// Log a workout session (multiple exercises at once)
app.post('/api/sessions', (req, res) => {
  const data = loadData();
  const { date, entries } = req.body;
  if (!entries || !entries.length) return res.status(400).json({ error: 'No entries' });

  const sessionDate = date || new Date().toISOString().split('T')[0];
  const results = [];

  for (const entry of entries) {
    const name = (entry.name || '').trim();
    if (!name) continue;
    if (!data.exercises[name]) {
      data.exercises[name] = { sessions: [], weightIncrement: 5 };
    }
    const validSets = (entry.sets || []).filter(s => s.weight > 0 && s.reps > 0);
    if (!validSets.length) continue;

    const totalVolume = validSets.reduce((s, set) => s + set.weight * set.reps, 0);
    const bestSet = validSets.reduce((best, s) => {
      return calc1RM(s.weight, s.reps) > calc1RM(best.weight, best.reps) ? s : best;
    }, validSets[0]);

    data.exercises[name].sessions.push({
      date: sessionDate,
      sets: validSets,
      totalVolume,
      estimated1RM: calc1RM(bestSet.weight, bestSet.reps),
      bestSet: { weight: bestSet.weight, reps: bestSet.reps }
    });

    data.exercises[name].sessions.sort((a, b) => a.date.localeCompare(b.date));

    results.push({
      name,
      estimated1RM: calc1RM(bestSet.weight, bestSet.reps),
      bestSet: { weight: bestSet.weight, reps: bestSet.reps }
    });
  }

  saveData(data);
  res.json({ success: true, results });
});

// Delete a specific session from an exercise
app.delete('/api/exercises/:name/sessions/:index', (req, res) => {
  const data = loadData();
  const name = decodeURIComponent(req.params.name);
  const idx = parseInt(req.params.index);
  if (!data.exercises[name] || !data.exercises[name].sessions[idx]) {
    return res.status(404).json({ error: 'Not found' });
  }
  data.exercises[name].sessions.splice(idx, 1);
  saveData(data);
  res.json({ success: true });
});

try {
  ensureDataFile();
} catch (e) {
  console.error('Data file init error:', e.message);
  process.exit(1);
}

app.listen(PORT, () => {
  console.log('\n  💪 IRONLOG running at http://localhost:' + PORT + '\n');
  console.log('  Data file: ' + DATA_FILE + '\n');
});
